<?php
/**
 * 文章API
 */
ob_start();
require_once __DIR__ . '/../config/init.php';
require_once ROOT_PATH . '/includes/Functions.php';
Auth::check();
if (ob_get_level()) ob_end_clean();

$db = Database::getInstance();
$userId = $_SESSION['user_id'];
$action = $_GET['action'] ?? '';

switch ($action) {
    case 'test_connection':
        // 清除之前可能存在的任何输出（PHP警告等）
        if (ob_get_level()) ob_end_clean();
        
        $input = json_decode(file_get_contents('php://input'), true);
        $model = $input['model'] ?? 'deepseek';
        $apiKey = $input['api_key'] ?? '';
        $customEndpoint = $input['endpoint'] ?? '';

        if (empty($apiKey)) {
            jsonResponse(['success' => false, 'message' => '请输入API Key']);
        }

        try {
            $generator = new AIGenerator();
            $result = $generator->testConnection($model, $apiKey, $customEndpoint);
            jsonResponse($result);
        } catch (Exception $e) {
            jsonResponse(['success' => false, 'message' => '错误: ' . $e->getMessage()]);
        }
        break;

    case 'preview':
        $id = intval($_GET['id'] ?? 0);
        $article = $db->fetchOne("SELECT * FROM articles WHERE id=? AND user_id=?", [$id, $userId]);
        if ($article) {
            jsonResponse(['success' => true, 'title' => $article['title'], 'content' => $article['content']]);
        }
        jsonResponse(['success' => false, 'message' => '文章不存在']);
        break;

    case 'delete':
        $id = intval($_GET['id'] ?? 0);
        $db->delete('articles', 'id=? AND user_id=?', [$id, $userId]);
        jsonResponse(['success' => true]);
        break;

    case 'batch_generate':
        // 获取选中的文章ID（如果有）
        $input = json_decode(file_get_contents('php://input'), true);
        $selectedIds = $input['ids'] ?? [];

        if (!empty($selectedIds)) {
            // 只生成选中的、状态为pending的文章
            $placeholders = implode(',', array_fill(0, count($selectedIds), '?'));
            $pending = $db->fetchAll(
                "SELECT * FROM articles WHERE user_id=? AND id IN ({$placeholders}) AND status='pending' LIMIT 50",
                array_merge([$userId], $selectedIds)
            );
        } else {
            // 没有选中则生成所有pending
            $pending = $db->fetchAll(
                "SELECT * FROM articles WHERE user_id=? AND status='pending' LIMIT 50",
                [$userId]
            );
        }

        if (empty($pending)) {
            jsonResponse(['success' => false, 'message' => '没有待生成的文章', 'total' => 0]);
        }

        // 获取配置（检查是否有可用的API Key - 从模板或全局配置）
        $hasApiKey = false;
        try {
            $hasApiKey = $db->count('article_templates', 'user_id=? AND api_key IS NOT NULL AND api_key != ""', [$userId]) > 0;
        } catch (Exception $e) {}
        if (!$hasApiKey) {
            $config = $db->fetchOne("SELECT * FROM global_config WHERE user_id=?", [$userId]);
            $hasApiKey = $config && !empty($config['api_key']);
        }
        if (!$hasApiKey) {
            jsonResponse(['success' => false, 'message' => '请先配置API Key（在模板或全局配置中）', 'total' => 0]);
        }

        // 标记为生成中
        foreach ($pending as $article) {
            $db->update('articles', ['status' => 'generating'], 'id=?', [$article['id']]);
        }

        // 初始化进度文件（只标记总数，不阻塞执行）
        $progressFile = UPLOAD_PATH . "progress_{$userId}.json";
        file_put_contents($progressFile, json_encode([
            'total' => count($pending),
            'done' => 0,
            'current' => '',
            'started_at' => date('Y-m-d H:i:s'),
        ]));

        writeLog('article', '批量生成', "启动生成，共" . count($pending) . "篇文章");
        jsonResponse(['success' => true, 'total' => count($pending), 'done' => 0]);
        break;

    case 'generate_status':
        $progressFile = UPLOAD_PATH . "progress_{$userId}.json";

        // 检查是否有正在生成的文章（逐个处理，避免超时）
        $generating = $db->fetchOne(
            "SELECT * FROM articles WHERE user_id=? AND status='generating' ORDER BY id ASC LIMIT 1",
            [$userId]
        );

        if ($generating) {
            // 获取配置 - 优先使用文章绑定的模板，否则使用全局配置
            $config = null;
            if (!empty($generating['template_id'])) {
                try {
                    $config = $db->fetchOne("SELECT * FROM article_templates WHERE id=? AND user_id=?", [$generating['template_id'], $userId]);
                } catch (Exception $e) {}
            }

            // 从挖词任务继承模板和发布目标
            if (!$config || empty($generating['publish_site_id'])) {
                try {
                    // 通过关键词找到对应的任务
                    $kwTask = $db->fetchOne(
                        "SELECT kt.bound_site_id, kt.bound_category_id, kt.template_id FROM keyword_results kr LEFT JOIN keyword_tasks kt ON kr.task_id = kt.id WHERE kr.user_id=? AND kr.keyword=? AND kt.id IS NOT NULL LIMIT 1",
                        [$userId, $generating['keyword']]
                    );
                    if ($kwTask) {
                        if (!$config && !empty($kwTask['template_id'])) {
                            $config = $db->fetchOne("SELECT * FROM article_templates WHERE id=? AND user_id=?", [$kwTask['template_id'], $userId]);
                        }
                        if (empty($generating['publish_site_id']) && !empty($kwTask['bound_site_id'])) {
                            $db->update('articles', [
                                'publish_site_id' => $kwTask['bound_site_id'],
                                'publish_category_id' => $kwTask['bound_category_id'],
                            ], 'id=?', [$generating['id']]);
                        }
                    }
                } catch (Exception $e) {}
            }

            if (!$config) {
                $config = $db->fetchOne("SELECT * FROM global_config WHERE user_id=?", [$userId]);
            }

            if (!$config || empty($config['api_key'])) {
                // 没有配置，标记失败
                $db->update('articles', ['status' => 'failed', 'error_message' => '未配置API Key'], 'id=?', [$generating['id']]);
            } else {
                // 生成这一篇
                $generator = new AIGenerator();
                $result = $generator->generateArticle($generating['keyword'], $config);

                if ($result['success']) {
                    $wordCount = mb_strlen(strip_tags($result['content']));
                    $db->update('articles', [
                        'title' => $result['title'],
                        'content' => $result['content'],
                        'content_type' => ($config['export_content_type'] ?? 'html') === 'html' ? 'html' : 'text',
                        'word_count' => $wordCount,
                        'status' => 'generated',
                    ], 'id=?', [$generating['id']]);
                } else {
                    $db->update('articles', [
                        'status' => 'failed',
                        'error_message' => $result['message'] ?? '生成失败',
                    ], 'id=?', [$generating['id']]);
                }
            }

            // 更新进度
            $totalGenerating = $db->count('articles', 'user_id=? AND status="generating"', [$userId]);
            $totalGenerated = $db->count('articles', 'user_id=? AND status="generated"', [$userId]);
            $totalFailed = $db->count('articles', 'user_id=? AND status="failed"', [$userId]);
            $done = $totalGenerated + $totalFailed;

            // 读取总数
            $total = 0;
            if (file_exists($progressFile)) {
                $progress = json_decode(file_get_contents($progressFile), true);
                $total = $progress['total'] ?? 0;
            }

            file_put_contents($progressFile, json_encode([
                'total' => $total,
                'done' => $done,
                'current' => $generating['keyword'],
                'started_at' => date('Y-m-d H:i:s'),
            ]));

            jsonResponse([
                'total' => $total,
                'done' => $done,
                'current' => $generating['keyword'],
            ]);
        } else {
            // 没有正在生成的，返回当前进度
            if (file_exists($progressFile)) {
                $progress = json_decode(file_get_contents($progressFile), true);
                $totalGenerated = $db->count('articles', 'user_id=? AND status="generated"', [$userId]);
                $totalFailed = $db->count('articles', 'user_id=? AND status="failed"', [$userId]);
                $progress['done'] = $totalGenerated + $totalFailed;
                $progress['current'] = '完成';
                jsonResponse($progress);
            }
            jsonResponse(['total' => 0, 'done' => 0, 'current' => '']);
        }
        break;

    case 'start_publish':
        $articles = $db->fetchAll(
            "SELECT * FROM articles WHERE user_id=? AND status='generated' LIMIT 20",
            [$userId]
        );

        if (empty($articles)) {
            jsonResponse(['success' => false, 'message' => '没有待发布的文章']);
        }

        // 获取全局配置作为回退
        $globalConfig = $db->fetchOne("SELECT * FROM global_config WHERE user_id=?", [$userId]);
        $globalSiteId = $globalConfig['site_id'] ?? 0;
        $globalCategoryId = $globalConfig['category_id'] ?? 0;

        $published = 0;

        // 获取发布间隔设置（取第一个有设置的站点）
        $publishInterval = 0;
        $randomInterval = false;
        foreach ($articles as $tmpArt) {
            if (!empty($tmpArt['publish_site_id'])) {
                try {
                    $tmpSettings = $db->fetchOne("SELECT * FROM site_publish_settings WHERE site_id=? AND user_id=?", [$tmpArt['publish_site_id'], $userId]);
                    if ($tmpSettings && intval($tmpSettings['publish_interval']) > 0) {
                        $publishInterval = intval($tmpSettings['publish_interval']);
                        $randomInterval = intval($tmpSettings['random_interval'] ?? 0) === 1;
                        break;
                    }
                } catch (Exception $e) {}
            }
        }

        foreach ($articles as $article) {
            // 发布间隔处理
            if ($publishInterval > 0 && $published > 0) {
                $delay = $randomInterval ? rand(1, $publishInterval * 60) : $publishInterval * 60;
                sleep(min($delay, 300)); // 最多sleep 5分钟防止超时
            }
            // 确定该文章的发布目标：优先使用文章自身的绑定，否则用全局配置
            $articleSiteId = !empty($article['publish_site_id']) ? $article['publish_site_id'] : $globalSiteId;
            $articleCategoryId = !empty($article['publish_category_id']) ? $article['publish_category_id'] : $globalCategoryId;

            if (!$articleSiteId) {
                continue; // 跳过没有发布目标的文章
            }

            $site = $db->fetchOne("SELECT * FROM sites WHERE id=?", [$articleSiteId]);
            if (!$site) continue;

            $publisher = new WordPressPublisher($site['domain'], $site['username'], $site['password']);

            $db->update('articles', ['status' => 'publishing'], 'id=?', [$article['id']]);

            $result = $publisher->publishPost(
                $article['title'],
                $article['content'],
                $articleCategoryId ? intval($articleCategoryId) : 0
            );

            if ($result['success']) {
                $db->update('articles', [
                    'status' => 'published',
                    'publish_site' => $site['domain'],
                    'publish_post_id' => $result['post_id'],
                    'published_at' => date('Y-m-d H:i:s'),
                ], 'id=?', [$article['id']]);

                // 更新站点的最后发布时间
                $db->update('sites', ['last_publish' => date('Y-m-d H:i:s')], 'id=?', [$site['id']]);

                $db->insert('publish_logs', [
                    'site_id' => $site['id'],
                    'article_id' => $article['id'],
                    'user_id' => $userId,
                    'action' => '发布文章',
                    'status' => 'success',
                    'message' => '文章ID: ' . $result['post_id'],
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
                $published++;
            } else {
                $db->update('articles', [
                    'status' => 'failed',
                    'error_message' => $result['message'],
                ], 'id=?', [$article['id']]);

                $db->insert('publish_logs', [
                    'site_id' => $site['id'],
                    'article_id' => $article['id'],
                    'user_id' => $userId,
                    'action' => '发布文章',
                    'status' => 'failed',
                    'message' => $result['message'],
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
            }
        }

        writeLog('article', '批量发布', "发布{$published}篇文章");
        jsonResponse(['success' => true, 'published' => $published]);
        break;

    case 'export':
        $format = $_GET['format'] ?? 'html';
        $articles = $db->fetchAll(
            "SELECT * FROM articles WHERE user_id=? AND status IN ('generated','published') ORDER BY created_at DESC",
            [$userId]
        );

        if ($format === 'excel') {
            // 导出CSV（Excel兼容）
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename=articles_' . date('YmdHis') . '.csv');
            echo "\xEF\xBB\xBF"; // UTF-8 BOM
            echo "ID,关键词,标题,字数,状态,发布时间\n";
            foreach ($articles as $a) {
                echo implode(',', [
                    $a['id'],
                    '"' . str_replace('"', '""', $a['keyword']) . '"',
                    '"' . str_replace('"', '""', $a['title']) . '"',
                    $a['word_count'],
                    $a['status'],
                    $a['published_at'] ?? '',
                ]) . "\n";
            }
            exit;
        }

        if ($format === 'txt') {
            header('Content-Type: text/plain; charset=utf-8');
            header('Content-Disposition: attachment; filename=articles_' . date('YmdHis') . '.txt');
            foreach ($articles as $a) {
                echo "标题: " . $a['title'] . "\n";
                echo "关键词: " . $a['keyword'] . "\n";
                echo "---\n";
                echo strip_tags($a['content']) . "\n";
                echo "========================================\n\n";
            }
            exit;
        }

        // HTML格式 - 打包为ZIP
        $zipFile = UPLOAD_PATH . 'articles_' . $userId . '_' . date('YmdHis') . '.zip';
        $zip = new ZipArchive();
        if ($zip->open($zipFile, ZipArchive::CREATE) === true) {
            foreach ($articles as $idx => $a) {
                $html = "<!DOCTYPE html><html><head><meta charset='utf-8'><title>" . htmlspecialchars($a['title']) . "</title></head><body>";
                $html .= "<h1>" . htmlspecialchars($a['title']) . "</h1>";
                $html .= "<p><strong>关键词:</strong> " . htmlspecialchars($a['keyword']) . "</p>";
                $html .= $a['content'];
                $html .= "</body></html>";
                $zip->addFromString(($idx + 1) . '_' . preg_replace('/[^\w\x{4e00}-\x{9fa5}]/u', '_', $a['title']) . '.html', $html);
            }
            $zip->close();
            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename=' . basename($zipFile));
            readfile($zipFile);
            unlink($zipFile);
            exit;
        }
        jsonResponse(['success' => false, 'message' => '导出失败']);
        break;

    default:
        jsonResponse(['success' => false, 'message' => '未知操作'], 400);
}
